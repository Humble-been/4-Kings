import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import TopNav from '@/components/TopNav';
import LeaderboardView from './LeaderboardView';

export default async function LeaderboardPage() {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  const { data: currentSeason } = await supabase
    .from('seasons')
    .select('id')
    .eq('is_current', true)
    .maybeSingle();

  const { data: gameweeks } = await supabase
    .from('gameweeks')
    .select('id, status')
    .in('status', ['scored', 'locked'])
    .order('id', { ascending: false });

  // Overall leaderboard: sum of total_points per manager for the current season
  const { data: overallRows } = await supabase
    .from('manager_gw_results')
    .select('manager_id, total_points, managers(display_name)')
    .eq('season_id', currentSeason?.id ?? '');

  const overallMap = new Map<string, { name: string; total: number }>();
  (overallRows ?? []).forEach((row: any) => {
    const name = row.managers?.display_name ?? 'Unknown';
    const prev = overallMap.get(row.manager_id)?.total ?? 0;
    overallMap.set(row.manager_id, { name, total: prev + row.total_points });
  });
  const overall = Array.from(overallMap.values()).sort((a, b) => b.total - a.total);

  // Most recent scored gameweek, for the default GW tab
  const latestGw = gameweeks?.find((g) => g.status === 'scored')?.id ?? gameweeks?.[0]?.id ?? null;

  let gwRows: any[] = [];
  if (latestGw) {
    const { data } = await supabase
      .from('manager_gw_results')
      .select('manager_id, total_points, captain_bonus, managers(display_name)')
      .eq('gameweek_id', latestGw)
      .order('total_points', { ascending: false });
    gwRows = data ?? [];
  }

  return (
    <div className="shell">
      <TopNav />
      <h1>Leaderboard</h1>
      <p className="subtext">Ties on the gameweek board are broken by captain points. Overall ties share rank.</p>
      <LeaderboardView overall={overall} gwRows={gwRows} gameweeks={gameweeks ?? []} latestGw={latestGw} />
    </div>
  );
}
