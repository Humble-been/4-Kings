'use client';

import { useState, useMemo } from 'react';

type OverallRow = { name: string; total: number };
type GwRow = { manager_id: string; total_points: number; captain_bonus: number; managers: { display_name: string } };
type Gameweek = { id: number; status: string };

export default function LeaderboardView({
  overall,
  gwRows,
  gameweeks,
  latestGw,
}: {
  overall: OverallRow[];
  gwRows: GwRow[];
  gameweeks: Gameweek[];
  latestGw: number | null;
}) {
  const [tab, setTab] = useState<'gw' | 'overall'>('gw');

  // Rank with tie handling: GW board uses captain_bonus as tiebreaker before sharing rank,
  // overall board shares rank on any tie (no tiebreaker), per the agreed design.
  const rankedGw = useMemo(() => {
    const sorted = [...gwRows].sort((a, b) => {
      if (b.total_points !== a.total_points) return b.total_points - a.total_points;
      return b.captain_bonus - a.captain_bonus;
    });
    let rank = 0;
    let prevTotal: number | null = null;
    let prevCaptain: number | null = null;
    return sorted.map((row, i) => {
      const isTie = row.total_points === prevTotal && row.captain_bonus === prevCaptain;
      if (!isTie) rank = i + 1;
      prevTotal = row.total_points;
      prevCaptain = row.captain_bonus;
      return { ...row, rank };
    });
  }, [gwRows]);

  const rankedOverall = useMemo(() => {
    let rank = 0;
    let prevTotal: number | null = null;
    return overall.map((row, i) => {
      const isTie = row.total === prevTotal;
      if (!isTie) rank = i + 1;
      prevTotal = row.total;
      return { ...row, rank };
    });
  }, [overall]);

  return (
    <div>
      <div className="leaderboard-tabs">
        <button className={tab === 'gw' ? 'active' : ''} onClick={() => setTab('gw')}>
          Gameweek {latestGw ?? ''}
        </button>
        <button className={tab === 'overall' ? 'active' : ''} onClick={() => setTab('overall')}>
          Overall
        </button>
      </div>

      {tab === 'gw' && (
        <>
          {rankedGw.length === 0 ? (
            <div className="empty-state">No scored gameweeks yet. Check back after the next deadline.</div>
          ) : (
            rankedGw.map((row) => (
              <div className="leaderboard-row" key={row.manager_id}>
                <span className={`rank ${row.rank <= 3 ? 'top3' : ''}`}>{row.rank}</span>
                <span className="lb-name">{row.managers?.display_name ?? 'Unknown'}</span>
                <span className="lb-points">{row.total_points}</span>
              </div>
            ))
          )}
        </>
      )}

      {tab === 'overall' && (
        <>
          {rankedOverall.length === 0 ? (
            <div className="empty-state">No results yet this season.</div>
          ) : (
            rankedOverall.map((row) => (
              <div className="leaderboard-row" key={row.name}>
                <span className={`rank ${row.rank <= 3 ? 'top3' : ''}`}>{row.rank}</span>
                <span className="lb-name">{row.name}</span>
                <span className="lb-points">{row.total}</span>
              </div>
            ))
          )}
        </>
      )}
    </div>
  );
}
