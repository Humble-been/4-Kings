import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: '4 Kings',
  description: 'Pick your four. Crown your captain.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
