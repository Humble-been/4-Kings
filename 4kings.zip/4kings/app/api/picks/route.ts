import { NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';

// Submits or updates a manager's picks for a gameweek.
// Uses the regular (non-admin) client so Supabase RLS policies enforce:
//  - manager_id must match the logged-in user
//  - the gameweek must still be 'open' and before pick_deadline
// The captain-is-one-of-the-four check is enforced by the DB constraint too, as a backstop.
export async function POST(request: Request) {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) {
    return NextResponse.json({ error: 'Not logged in' }, { status: 401 });
  }

  const body = await request.json();
  const { gameweekId, gkPlayerId, defPlayerId, midPlayerId, fwdPlayerId, captainPlayerId } = body;

  if (!gameweekId || !gkPlayerId || !defPlayerId || !midPlayerId || !fwdPlayerId || !captainPlayerId) {
    return NextResponse.json({ error: 'All four picks and a captain are required' }, { status: 400 });
  }

  if (![gkPlayerId, defPlayerId, midPlayerId, fwdPlayerId].includes(captainPlayerId)) {
    return NextResponse.json({ error: 'Captain must be one of your four picks' }, { status: 400 });
  }

  const { data, error } = await supabase
    .from('picks')
    .upsert(
      {
        manager_id: user.id,
        gameweek_id: gameweekId,
        gk_player_id: gkPlayerId,
        def_player_id: defPlayerId,
        mid_player_id: midPlayerId,
        fwd_player_id: fwdPlayerId,
        captain_player_id: captainPlayerId,
        submitted_at: new Date().toISOString(),
      },
      { onConflict: 'manager_id,gameweek_id' }
    )
    .select()
    .single();

  if (error) {
    // RLS will reject this with a permissions error if the deadline has passed
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  return NextResponse.json({ ok: true, pick: data });
}
