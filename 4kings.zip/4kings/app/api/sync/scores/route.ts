import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/server';
import { fetchLiveGameweek, mapLiveScores } from '@/lib/fpl';

// Pulls live points for a gameweek, but ONLY for players that were actually picked
// (the "dedup" step from the original design — no point storing scores for players nobody chose).
// Then recomputes manager_gw_results for everyone who picked that GW.
// Safe to call again later if FPL adjusts bonus points — it overwrites, doesn't duplicate.
export async function POST(request: Request) {
  const secret = request.headers.get('x-sync-secret') || new URL(request.url).searchParams.get('secret');
  if (secret !== process.env.SYNC_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { gameweekId } = await request.json();
  if (!gameweekId) {
    return NextResponse.json({ error: 'gameweekId is required' }, { status: 400 });
  }

  const supabase = createAdminClient();

  try {
    // 1. Find every unique player picked in this gameweek
    const { data: picks, error: picksError } = await supabase
      .from('picks')
      .select('id, manager_id, gk_player_id, def_player_id, mid_player_id, fwd_player_id, captain_player_id')
      .eq('gameweek_id', gameweekId);
    if (picksError) throw picksError;

    if (!picks || picks.length === 0) {
      return NextResponse.json({ ok: true, message: 'No picks found for this gameweek.' });
    }

    const uniquePlayerIds = new Set<number>();
    picks.forEach((p) => {
      uniquePlayerIds.add(p.gk_player_id);
      uniquePlayerIds.add(p.def_player_id);
      uniquePlayerIds.add(p.mid_player_id);
      uniquePlayerIds.add(p.fwd_player_id);
    });

    // 2. Pull live FPL scores for the whole gameweek, filter down to just the picked players
    const liveData = await fetchLiveGameweek(gameweekId);
    const allScores = mapLiveScores(liveData, gameweekId);
    const relevantScores = allScores.filter((s: any) => uniquePlayerIds.has(s.player_id));

    const { error: scoresError } = await supabase
      .from('player_gw_scores')
      .upsert(relevantScores, { onConflict: 'player_id,gameweek_id' });
    if (scoresError) throw scoresError;

    // 3. Build a quick lookup of player_id -> points
    const pointsMap = new Map<number, number>();
    relevantScores.forEach((s: any) => pointsMap.set(s.player_id, s.points));

    // 4. Get season for this gameweek
    const { data: gw, error: gwError } = await supabase
      .from('gameweeks')
      .select('season_id')
      .eq('id', gameweekId)
      .single();
    if (gwError) throw gwError;

    // 5. Compute each manager's result
    const results = picks.map((p) => {
      const gkPts = pointsMap.get(p.gk_player_id) ?? 0;
      const defPts = pointsMap.get(p.def_player_id) ?? 0;
      const midPts = pointsMap.get(p.mid_player_id) ?? 0;
      const fwdPts = pointsMap.get(p.fwd_player_id) ?? 0;
      const captainPts = pointsMap.get(p.captain_player_id) ?? 0;
      const total = gkPts + defPts + midPts + fwdPts + captainPts; // captain counted twice: once in position total, once as bonus

      return {
        manager_id: p.manager_id,
        gameweek_id: gameweekId,
        season_id: gw.season_id,
        gk_points: gkPts,
        def_points: defPts,
        mid_points: midPts,
        fwd_points: fwdPts,
        captain_bonus: captainPts,
        total_points: total,
      };
    });

    const { error: resultsError } = await supabase
      .from('manager_gw_results')
      .upsert(results, { onConflict: 'manager_id,gameweek_id' });
    if (resultsError) throw resultsError;

    // 6. Mark gameweek as scored
    await supabase.from('gameweeks').update({ status: 'scored' }).eq('id', gameweekId);

    return NextResponse.json({
      ok: true,
      players_scored: relevantScores.length,
      managers_scored: results.length,
    });
  } catch (err: any) {
    console.error('Sync scores error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
