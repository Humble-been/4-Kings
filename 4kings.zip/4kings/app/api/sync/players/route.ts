import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/server';
import { fetchBootstrap, mapPlayers, mapGameweeks } from '@/lib/fpl';

// Pulls players + gameweeks from FPL's bootstrap-static and upserts into Supabase.
// Call this: manually from an admin button, or on a schedule (e.g. Vercel Cron, hourly).
// Safe to call repeatedly — upserts, does not duplicate.
export async function POST(request: Request) {
  // Basic protection so randoms can't trigger syncs — set SYNC_SECRET in your env vars
  // and pass it as ?secret=... or an Authorization header when calling this route.
  const secret = request.headers.get('x-sync-secret') || new URL(request.url).searchParams.get('secret');
  if (secret !== process.env.SYNC_SECRET) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const supabase = createAdminClient();

  try {
    const bootstrap = await fetchBootstrap();

    // Ensure current season exists
    const seasonId = getCurrentSeasonId();
    await supabase
      .from('seasons')
      .upsert({ id: seasonId, is_current: true }, { onConflict: 'id' });

    const players = mapPlayers(bootstrap);
    const { error: playersError } = await supabase
      .from('players')
      .upsert(players, { onConflict: 'id' });
    if (playersError) throw playersError;

    const gameweeks = mapGameweeks(bootstrap, seasonId);
    const { error: gwError } = await supabase
      .from('gameweeks')
      .upsert(gameweeks, { onConflict: 'id' });
    if (gwError) throw gwError;

    return NextResponse.json({
      ok: true,
      players_synced: players.length,
      gameweeks_synced: gameweeks.length,
    });
  } catch (err: any) {
    console.error('Sync players error:', err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

function getCurrentSeasonId() {
  // Premier League season spans Aug–May. If we're Jul or later, season starts this year.
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth(); // 0-indexed
  const startYear = month >= 6 ? year : year - 1;
  return `${startYear}-${String(startYear + 1).slice(2)}`;
}
