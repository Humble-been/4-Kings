import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import TopNav from '@/components/TopNav';
import PicksForm from './PicksForm';

export default async function PicksPage() {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) redirect('/login');

  // Find the currently open gameweek
  const { data: gameweek } = await supabase
    .from('gameweeks')
    .select('*')
    .eq('status', 'open')
    .order('id', { ascending: true })
    .limit(1)
    .maybeSingle();

  // All players, split by position client-side
  const { data: players } = await supabase
    .from('players')
    .select('id, name, team, position, status, chance_of_playing')
    .order('name');

  // This manager's existing pick for this GW, if any (so the form pre-fills on edit)
  let existingPick = null;
  if (gameweek) {
    const { data } = await supabase
      .from('picks')
      .select('*')
      .eq('manager_id', user.id)
      .eq('gameweek_id', gameweek.id)
      .maybeSingle();
    existingPick = data;
  }

  return (
    <div className="shell">
      <TopNav />
      <h1>Pick your four</h1>
      <p className="subtext">One from each position. Crown your captain for double points.</p>

      {!gameweek ? (
        <div className="empty-state">
          There&apos;s no gameweek open for picks right now. Check back closer to the next deadline.
        </div>
      ) : (
        <PicksForm gameweek={gameweek} players={players ?? []} existingPick={existingPick} />
      )}
    </div>
  );
}
