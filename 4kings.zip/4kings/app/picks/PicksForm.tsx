'use client';

import { useState, useMemo } from 'react';
import PositionSlot, { Player } from '@/components/PositionSlot';

type Gameweek = {
  id: number;
  pick_deadline: string;
  status: string;
};

type ExistingPick = {
  gk_player_id: number;
  def_player_id: number;
  mid_player_id: number;
  fwd_player_id: number;
  captain_player_id: number;
} | null;

export default function PicksForm({
  gameweek,
  players,
  existingPick,
}: {
  gameweek: Gameweek;
  players: Player[];
  existingPick: ExistingPick;
}) {
  const findPlayer = (id: number | undefined) => players.find((p) => p.id === id) ?? null;

  const [gk, setGk] = useState<Player | null>(findPlayer(existingPick?.gk_player_id));
  const [def, setDef] = useState<Player | null>(findPlayer(existingPick?.def_player_id));
  const [mid, setMid] = useState<Player | null>(findPlayer(existingPick?.mid_player_id));
  const [fwd, setFwd] = useState<Player | null>(findPlayer(existingPick?.fwd_player_id));
  const [captainId, setCaptainId] = useState<number | null>(existingPick?.captain_player_id ?? null);

  const [status, setStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const byPosition = useMemo(
    () => ({
      GK: players.filter((p) => p.position === 'GK'),
      DEF: players.filter((p) => p.position === 'DEF'),
      MID: players.filter((p) => p.position === 'MID'),
      FWD: players.filter((p) => p.position === 'FWD'),
    }),
    [players]
  );

  const picks = [gk, def, mid, fwd].filter(Boolean) as Player[];
  const allFourPicked = gk && def && mid && fwd;
  const deadlinePassed = new Date() > new Date(gameweek.pick_deadline);

  // If a previously-selected captain gets swapped out, clear captain selection
  function selectAndSyncCaptain(setter: (p: Player | null) => void, player: Player | null, prevId?: number) {
    setter(player);
    if (prevId && captainId === prevId) setCaptainId(null);
  }

  async function handleSubmit() {
    if (!allFourPicked || !captainId) return;
    setStatus('saving');
    setErrorMsg('');

    try {
      const res = await fetch('/api/picks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gameweekId: gameweek.id,
          gkPlayerId: gk!.id,
          defPlayerId: def!.id,
          midPlayerId: mid!.id,
          fwdPlayerId: fwd!.id,
          captainPlayerId: captainId,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Something went wrong');
      setStatus('saved');
    } catch (err: any) {
      setStatus('error');
      setErrorMsg(err.message);
    }
  }

  const deadlineLabel = new Date(gameweek.pick_deadline).toLocaleString(undefined, {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div>
      <div className="deadline-strip">
        <span>Gameweek {gameweek.id} deadline</span>
        <strong>{deadlineLabel}</strong>
      </div>

      {deadlinePassed ? (
        <div className="empty-state">Picks are locked for this gameweek. Check the leaderboard once it&apos;s scored.</div>
      ) : (
        <>
          <PositionSlot
            position="GK"
            players={byPosition.GK}
            selected={gk}
            onSelect={(p) => selectAndSyncCaptain(setGk, p, gk?.id)}
          />
          <PositionSlot
            position="DEF"
            players={byPosition.DEF}
            selected={def}
            onSelect={(p) => selectAndSyncCaptain(setDef, p, def?.id)}
          />
          <PositionSlot
            position="MID"
            players={byPosition.MID}
            selected={mid}
            onSelect={(p) => selectAndSyncCaptain(setMid, p, mid?.id)}
          />
          <PositionSlot
            position="FWD"
            players={byPosition.FWD}
            selected={fwd}
            onSelect={(p) => selectAndSyncCaptain(setFwd, p, fwd?.id)}
          />

          <h2 style={{ marginTop: 28 }}>Captain</h2>
          <p className="subtext" style={{ marginBottom: 0 }}>
            Their points count double this gameweek.
          </p>
          <div className="captain-row">
            {picks.length === 0 && (
              <span style={{ fontSize: 13, color: 'rgba(247,245,240,0.4)' }}>
                Pick your four players first.
              </span>
            )}
            {picks.map((p) => (
              <button
                key={p.id}
                className={`captain-pill ${captainId === p.id ? 'active' : ''}`}
                onClick={() => setCaptainId(p.id)}
              >
                {captainId === p.id ? '👑 ' : ''}
                {p.name}
              </button>
            ))}
          </div>

          {status === 'error' && <div className="error-text">{errorMsg}</div>}
          {status === 'saved' && (
            <div style={{ color: '#8fd4ab', fontSize: 13, marginBottom: 14 }}>
              ✓ Picks saved. You can change them any time before the deadline.
            </div>
          )}

          <button
            className="btn-primary"
            disabled={!allFourPicked || !captainId || status === 'saving'}
            onClick={handleSubmit}
          >
            {status === 'saving' ? 'Saving…' : existingPick ? 'Update picks' : 'Submit picks'}
          </button>
        </>
      )}
    </div>
  );
}
