'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function SignupPage() {
  const router = useRouter();
  const supabase = createClient();

  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [checkEmail, setCheckEmail] = useState(false);

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { display_name: displayName } },
    });

    if (error) {
      setError(error.message);
      setLoading(false);
      return;
    }

    // If email confirmation is required, there won't be a session yet
    if (data.session) {
      router.push('/picks');
      router.refresh();
    } else {
      setCheckEmail(true);
      setLoading(false);
    }
  }

  if (checkEmail) {
    return (
      <div className="shell">
        <div className="auth-card">
          <h1 style={{ textAlign: 'center' }}>Check your email</h1>
          <p className="subtext" style={{ textAlign: 'center', marginBottom: 0 }}>
            We&apos;ve sent a confirmation link to {email}. Click it, then come back and sign in.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="shell">
      <div className="auth-card">
        <h1 style={{ textAlign: 'center' }}>👑 4 Kings</h1>
        <p className="subtext" style={{ textAlign: 'center' }}>
          Create your account
        </p>
        <form onSubmit={handleSignup}>
          <div className="field">
            <label htmlFor="displayName">Manager name</label>
            <input
              id="displayName"
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Shown on the leaderboard"
              required
            />
          </div>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              minLength={6}
              required
            />
          </div>
          {error && <div className="error-text">{error}</div>}
          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? 'Creating account…' : 'Create account'}
          </button>
        </form>
        <div className="auth-switch">
          Already playing? <Link href="/login">Sign in</Link>
        </div>
      </div>
    </div>
  );
}
