-- 4 Kings 👑 — Supabase schema
-- Run this whole file once in the Supabase SQL Editor (Project → SQL Editor → New query → paste → Run)

-- ============================================================
-- MANAGERS  (extends Supabase auth.users)
-- ============================================================
create table if not exists managers (
  id uuid primary key references auth.users (id) on delete cascade,
  display_name text not null,
  created_at timestamptz not null default now()
);

-- Automatically create a managers row whenever someone signs up via Supabase Auth
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.managers (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'display_name', split_part(new.email, '@', 1)));
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- PLAYERS  (synced from FPL bootstrap-static)
-- ============================================================
create table if not exists players (
  id int primary key,                    -- FPL's own element id, reused directly
  name text not null,
  team text not null,
  position text not null check (position in ('GK', 'DEF', 'MID', 'FWD')),
  fpl_element_type int not null,
  status text default 'a',               -- FPL status code: a=available, d=doubtful, i=injured, s=suspended, u=unavailable
  chance_of_playing int,                  -- 0-100, null if unknown/fully fit
  updated_at timestamptz not null default now()
);

create index if not exists idx_players_position on players (position);

-- ============================================================
-- SEASONS
-- ============================================================
create table if not exists seasons (
  id text primary key,                   -- e.g. '2026-27'
  is_current boolean not null default false
);

-- ============================================================
-- GAMEWEEKS  (synced from FPL events)
-- ============================================================
create table if not exists gameweeks (
  id int primary key,                    -- FPL's GW number
  season_id text not null references seasons (id),
  deadline_time timestamptz not null,    -- raw FPL deadline
  pick_deadline timestamptz not null,    -- deadline_time + 30 minutes — what the app actually enforces
  status text not null default 'upcoming' check (status in ('upcoming', 'open', 'locked', 'scored')),
  is_current boolean not null default false
);

-- ============================================================
-- PICKS  (one row per manager per gameweek)
-- ============================================================
create table if not exists picks (
  id uuid primary key default gen_random_uuid(),
  manager_id uuid not null references managers (id) on delete cascade,
  gameweek_id int not null references gameweeks (id) on delete cascade,
  gk_player_id int not null references players (id),
  def_player_id int not null references players (id),
  mid_player_id int not null references players (id),
  fwd_player_id int not null references players (id),
  captain_player_id int not null references players (id),
  submitted_at timestamptz not null default now(),
  unique (manager_id, gameweek_id),
  -- captain must be one of the four picks
  constraint captain_is_one_of_picks check (
    captain_player_id in (gk_player_id, def_player_id, mid_player_id, fwd_player_id)
  )
);

-- ============================================================
-- PLAYER_GW_SCORES  (deduped per-player score per gameweek, auto-filled from FPL live data)
-- ============================================================
create table if not exists player_gw_scores (
  player_id int not null references players (id),
  gameweek_id int not null references gameweeks (id),
  points int not null default 0,
  synced_at timestamptz not null default now(),
  primary key (player_id, gameweek_id)
);

-- ============================================================
-- MANAGER_GW_RESULTS  (computed after each sync)
-- ============================================================
create table if not exists manager_gw_results (
  manager_id uuid not null references managers (id) on delete cascade,
  gameweek_id int not null references gameweeks (id) on delete cascade,
  season_id text not null references seasons (id),
  gk_points int not null default 0,
  def_points int not null default 0,
  mid_points int not null default 0,
  fwd_points int not null default 0,
  captain_bonus int not null default 0,   -- captain's points counted a second time
  total_points int not null default 0,
  primary key (manager_id, gameweek_id)
);

create index if not exists idx_results_season on manager_gw_results (season_id);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table managers enable row level security;
alter table picks enable row level security;
alter table manager_gw_results enable row level security;
alter table players enable row level security;
alter table gameweeks enable row level security;
alter table seasons enable row level security;
alter table player_gw_scores enable row level security;

-- Everyone (logged in) can read reference data
create policy "players are viewable by everyone" on players for select using (true);
create policy "gameweeks are viewable by everyone" on gameweeks for select using (true);
create policy "seasons are viewable by everyone" on seasons for select using (true);
create policy "scores are viewable by everyone" on player_gw_scores for select using (true);
create policy "managers are viewable by everyone" on managers for select using (true);
create policy "results are viewable by everyone" on manager_gw_results for select using (true);

-- Picks: managers can see everyone's picks ONLY after that gameweek is locked (prevents pick-sniping before deadline)
create policy "picks viewable after lock" on picks for select using (
  exists (
    select 1 from gameweeks
    where gameweeks.id = picks.gameweek_id
    and gameweeks.status in ('locked', 'scored')
  )
  or manager_id = auth.uid()
);

-- Managers can only insert/update their own picks, and only while the gameweek is still open
create policy "managers insert own picks while open" on picks for insert with check (
  manager_id = auth.uid()
  and exists (
    select 1 from gameweeks
    where gameweeks.id = picks.gameweek_id
    and gameweeks.status = 'open'
    and now() < gameweeks.pick_deadline
  )
);

create policy "managers update own picks while open" on picks for update using (
  manager_id = auth.uid()
  and exists (
    select 1 from gameweeks
    where gameweeks.id = picks.gameweek_id
    and gameweeks.status = 'open'
    and now() < gameweeks.pick_deadline
  )
);

create policy "managers update own display name" on managers for update using (id = auth.uid());

-- Writes to players / gameweeks / scores / results happen only via the service role key (server-side sync jobs),
-- so no insert/update/delete policies are defined for regular users on those tables — RLS blocks them by default.
