import { createBrowserClient } from '@supabase/ssr';

// Used in Client Components (browser). Reads the two PUBLIC keys —
// safe to expose, RLS policies in schema.sql control what they can actually do.
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
