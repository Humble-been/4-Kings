// Thin wrapper around the public, unofficial FPL API.
// No key required. Endpoints confirmed stable as of Sept 2026.

const FPL_BASE = 'https://fantasy.premierleague.com/api';

const POSITION_MAP: Record<number, 'GK' | 'DEF' | 'MID' | 'FWD'> = {
  1: 'GK',
  2: 'DEF',
  3: 'MID',
  4: 'FWD',
};

export async function fetchBootstrap() {
  const res = await fetch(`${FPL_BASE}/bootstrap-static/`, {
    // FPL data changes slowly outside matchdays — cache briefly to avoid hammering their API
    next: { revalidate: 300 },
  });
  if (!res.ok) throw new Error(`FPL bootstrap-static failed: ${res.status}`);
  return res.json();
}

export async function fetchLiveGameweek(gameweekId: number) {
  const res = await fetch(`${FPL_BASE}/event/${gameweekId}/live/`, {
    next: { revalidate: 60 }, // scores can update during/after matches — shorter cache
  });
  if (!res.ok) throw new Error(`FPL live event ${gameweekId} failed: ${res.status}`);
  return res.json();
}

export function mapPlayers(bootstrap: any) {
  return bootstrap.elements.map((el: any) => ({
    id: el.id,
    name: `${el.first_name} ${el.second_name}`.trim(),
    team: bootstrap.teams.find((t: any) => t.id === el.team)?.name ?? 'Unknown',
    position: POSITION_MAP[el.element_type] ?? 'MID',
    fpl_element_type: el.element_type,
    status: el.status, // 'a' available, 'd' doubtful, 'i' injured, 's' suspended, 'u' unavailable
    chance_of_playing: el.chance_of_playing_this_round,
  }));
}

export function mapGameweeks(bootstrap: any, seasonId: string) {
  return bootstrap.events.map((ev: any) => {
    const deadline = new Date(ev.deadline_time);
    const pickDeadline = new Date(deadline.getTime() + 30 * 60 * 1000); // +30 min per your rule

    let status: 'upcoming' | 'open' | 'locked' | 'scored' = 'upcoming';
    if (ev.finished) status = 'scored';
    else if (new Date() > pickDeadline) status = 'locked';
    else if (ev.is_current || ev.is_next) status = 'open';

    return {
      id: ev.id,
      season_id: seasonId,
      deadline_time: deadline.toISOString(),
      pick_deadline: pickDeadline.toISOString(),
      status,
      is_current: ev.is_current,
    };
  });
}

export function mapLiveScores(liveData: any, gameweekId: number) {
  return liveData.elements.map((el: any) => ({
    player_id: el.id,
    gameweek_id: gameweekId,
    points: el.stats.total_points,
    synced_at: new Date().toISOString(),
  }));
}
