# 4 Kings 👑

A weekly fantasy pick'em built on real FPL data. Pick 1 GK, 1 DEF, 1 MID, 1 FWD each gameweek, crown a captain for double points, and climb the leaderboard.

This README walks you through getting the whole thing live, from zero, with no coding required.

---

## What you'll need (both free)
- A **Supabase** account → [supabase.com](https://supabase.com)
- A **Vercel** account → [vercel.com](https://vercel.com)
- A **GitHub** account (Vercel deploys from a GitHub repo) → [github.com](https://github.com)

---

## Step 1 — Put this project on GitHub

1. Create a new, empty repository on GitHub (e.g. `4kings`).
2. Upload this whole project folder to it. Easiest way if you're not familiar with git:
   - On the repo page, click **Add file → Upload files**
   - Drag in everything from this project folder
   - Commit the changes

---

## Step 2 — Create your Supabase project

1. Go to [supabase.com](https://supabase.com) → **New project**
2. Pick a name (e.g. `4kings`), a database password (save it somewhere), and a region close to your users
3. Wait a minute or two for it to spin up
4. Once it's ready, go to the **SQL Editor** (left sidebar) → **New query**
5. Open `supabase/schema.sql` from this project, copy the whole thing, paste it into the SQL editor, and click **Run**
   - This creates every table, security rule, and the auto-profile trigger in one go
6. Go to **Project Settings → API**. You'll need three values from here in Step 4:
   - `Project URL`
   - `anon` `public` key
   - `service_role` `secret` key (click reveal)

### Turn off email confirmation (optional, but recommended to start)
By default Supabase requires users to click a confirmation email before they can log in. For a small private game this is often unnecessary friction. To turn it off:
- **Authentication → Providers → Email** → toggle off "Confirm email"
(You can turn it back on later if you open this up to a wider group.)

---

## Step 3 — Deploy to Vercel

1. Go to [vercel.com](https://vercel.com) → **Add New → Project**
2. Import the GitHub repo you created in Step 1
3. Before clicking Deploy, open **Environment Variables** and add these four (values from Step 2):

| Name | Value |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | your Supabase Project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | your Supabase anon public key |
| `SUPABASE_SERVICE_ROLE_KEY` | your Supabase service_role key |
| `SYNC_SECRET` | make up a long random password — this protects your data-sync endpoints |

4. Click **Deploy**. After a minute or two you'll get a live URL like `4kings.vercel.app`

---

## Step 4 — Load in the players and gameweeks

The site is live but the `players` and `gameweeks` tables are still empty. Trigger the first sync by visiting this URL in your browser (replace both placeholders):

```
https://YOUR-SITE.vercel.app/api/sync/players?secret=YOUR_SYNC_SECRET
```

You should see a JSON response like `{"ok":true,"players_synced":600+,"gameweeks_synced":38}`. That's every current FPL player and this season's 38 gameweeks now in your database.

**Keeping it fresh:** `vercel.json` in this project is already set up to auto-run this sync every hour via Vercel Cron, so player status/availability stays current without you doing anything. Open `vercel.json` and replace `REPLACE_WITH_YOUR_SYNC_SECRET` with your real `SYNC_SECRET` before/after deploying (then redeploy if you change it after the first deploy).

---

## Step 5 — Try it out

1. Visit your site, click **Create an account**, sign up
2. You should land on **My Picks** — if a gameweek is open, you can search and pick your four plus captain
3. Check **Leaderboard** — empty until a gameweek is scored (next step)

---

## Step 6 — Scoring a gameweek (after matches finish)

Once a gameweek's matches are done, trigger scoring by sending a POST request with the gameweek number. The simplest way without any coding tools is a free site like [reqbin.com](https://reqbin.com) or your browser's dev console — or ask me and I'll talk you through it when you're ready for this step. The request looks like:

```
POST https://YOUR-SITE.vercel.app/api/sync/scores
Header: x-sync-secret: YOUR_SYNC_SECRET
Body (JSON): { "gameweekId": 7 }
```

This pulls real FPL points for every player anyone picked that gameweek, and recalculates every manager's score and the leaderboard. It's safe to run again later if FPL adjusts bonus points after the fact — nothing gets duplicated.

*(Optional upgrade for later: a small admin page with a "Sync scores" button instead of doing this manually — happy to build that next if it'd help.)*

---

## Project structure

```
app/
  login/, signup/        — auth pages
  picks/                 — the pick screen (team-sheet style, 4 positions + captain)
  leaderboard/            — gameweek + overall tables, tie-break logic
  api/
    picks/                — manager submits/edits their picks (RLS-protected)
    sync/players/         — pulls players + gameweeks from FPL
    sync/scores/          — pulls scores for picked players, computes results
    auth/logout/
lib/
  supabase/               — client, server, and admin Supabase helpers
  fpl.ts                  — FPL API wrapper + data mapping
components/
  TopNav.tsx, PositionSlot.tsx
supabase/
  schema.sql              — full database schema, run once in Supabase SQL Editor
```

## How the rules from our design doc are enforced
- **Captain must be one of the 4 picks** — enforced both in the UI and as a database constraint
- **Picks editable until deadline** — the database only allows writes while a gameweek is `open` and before `pick_deadline` (FPL's real deadline + 30 min, recalculated on every sync)
- **Deduped scoring** — `/api/sync/scores` collects the unique set of picked players before pulling their points, exactly like the original manual process, just automatic
- **GW leaderboard tiebreaker** — sorts by total points, then captain points, then shares rank
- **Overall leaderboard** — no tiebreaker, ties share rank
- **Availability warnings** — shown as a badge next to any player who's doubtful/injured/suspended, never blocks the pick
- **Seasons** — every gameweek, pick, and result is tagged with a `season_id`, so a new season just means a new row in `seasons`, no data is lost
