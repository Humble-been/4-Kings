'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';

export default function TopNav() {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
    router.refresh();
  }

  return (
    <div className="top-bar">
      <Link href="/picks" className="brand">
        <span className="crown">👑</span> 4 Kings
      </Link>
      <nav className="top-nav">
        <Link href="/picks" className={pathname === '/picks' ? 'active' : ''}>
          My Picks
        </Link>
        <Link href="/leaderboard" className={pathname === '/leaderboard' ? 'active' : ''}>
          Leaderboard
        </Link>
        <button
          onClick={handleLogout}
          style={{ background: 'none', border: 'none', color: 'rgba(247,245,240,0.65)', cursor: 'pointer', fontSize: 14, padding: 0 }}
        >
          Sign out
        </button>
      </nav>
    </div>
  );
}
