'use client';

import { useState, useMemo } from 'react';

export type Player = {
  id: number;
  name: string;
  team: string;
  position: 'GK' | 'DEF' | 'MID' | 'FWD';
  status: string;
  chance_of_playing: number | null;
};

const POSITION_LABELS: Record<Player['position'], string> = {
  GK: 'Goalkeeper',
  DEF: 'Defender',
  MID: 'Midfielder',
  FWD: 'Forward',
};

function availabilityWarning(player: Player): string | null {
  if (player.status === 's') return '⚠ Suspended';
  if (player.status === 'i') return '⚠ Injured';
  if (player.status === 'u') return '⚠ Unavailable';
  if (player.status === 'd') {
    return player.chance_of_playing !== null
      ? `⚠ ${player.chance_of_playing}% chance of playing`
      : '⚠ Doubtful';
  }
  return null;
}

export default function PositionSlot({
  position,
  players,
  selected,
  onSelect,
}: {
  position: Player['position'];
  players: Player[];
  selected: Player | null;
  onSelect: (player: Player | null) => void;
}) {
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    if (!query.trim()) return players.slice(0, 8);
    const q = query.toLowerCase();
    return players.filter((p) => p.name.toLowerCase().includes(q) || p.team.toLowerCase().includes(q)).slice(0, 8);
  }, [players, query]);

  return (
    <div className="slot">
      <div className="slot-header">
        <div className="slot-badge">{position}</div>
        <div className="slot-title">{POSITION_LABELS[position]}</div>
      </div>
      <div className="slot-body">
        {selected ? (
          <div className="selected-chip">
            <div>
              <span className="player-name">{selected.name}</span>
              <span className="player-team">{selected.team}</span>
              {availabilityWarning(selected) && (
                <div className="flag-warning">{availabilityWarning(selected)}</div>
              )}
            </div>
            <button className="clear" onClick={() => onSelect(null)}>
              change
            </button>
          </div>
        ) : (
          <>
            <input
              className="player-search"
              placeholder={`Search ${POSITION_LABELS[position].toLowerCase()}s…`}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <div className="player-list">
              {filtered.length === 0 && (
                <div style={{ padding: '10px 4px', fontSize: 13, color: 'rgba(247,245,240,0.4)' }}>
                  No players found.
                </div>
              )}
              {filtered.map((p) => (
                <div key={p.id} className="player-row" onClick={() => onSelect(p)}>
                  <div>
                    <span className="player-name">{p.name}</span>
                    <span className="player-team">{p.team}</span>
                  </div>
                  {availabilityWarning(p) && <span className="flag-warning">{availabilityWarning(p)}</span>}
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
